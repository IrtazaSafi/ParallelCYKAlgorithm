import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Stream;

class triangleTable {
    volatile tableItem [][] table;
    ReentrantLock lock = new ReentrantLock();
    final int size;
    final GRAMMAR_SERIAL grammar;
    triangleTable(int _size,String filename) throws IOException {
        size = _size;
        table = new tableItem[size][size];
        for(int i = 0 ; i < size;i++){
            for(int j = 0; j < size;j++){
                table[j][i] = new tableItem(String.valueOf(j) + String.valueOf(i),false);
                if(i+j >= size){
                    table[j][i].coordinate = "~";
                }
                table[j][i].xCor = j;
                table[j][i].yCor = i;
            }
        }
        grammar = new GRAMMAR_SERIAL(filename);
    }

    tableItem get(int x, int y){
        return table[x][y];
    }

    tableItem multiply(tableItem first, tableItem second,int x, int y){
        if(first.isNull || second.isNull){
            return new tableItem(String.valueOf(x)+String.valueOf(y),true);
        }
        ArrayList<String> answer = new ArrayList<String>();
        first.vals.forEach((String f)->{
            second.vals.forEach((String s) ->{
                answer.add(f+s);
            });
        });

        tableItem ans = new tableItem(String.valueOf(x)+String.valueOf(y),false);
        ans.vals = answer;
        return ans;
    }

    tableItem union(ArrayList<tableItem> items,int x, int y){
        tableItem answer = new tableItem(String.valueOf(x)+String.valueOf(y),false);
        items.forEach(tableItem -> {
            if(!tableItem.isNull){
                tableItem.vals.forEach((String val)->{
                    answer.vals.add(val);
                });
            }
        });
        return reduce(answer);
    }

    tableItem reduce(tableItem item){
        ArrayList<String> reducedVals = new ArrayList<String>();
        item.vals.forEach((String val)->{
            grammar.getReverse(val).forEach(reducedVals::add);
        });
        Set<String> s = new HashSet<String>(reducedVals);
        reducedVals.clear();
        reducedVals.addAll(s);
        item.vals = reducedVals;

        item.isNull = item.vals.size() == 0;
        return item;
    }

    void print(){
       for(int i = size-1;i >=0 ; i--){
           for(int j = 0 ; j < size;j++){
               System.out.print(table[j][i].coordinate + " ");
           }
           System.out.println();
       }
    }

    void set(int x, int y,String _val){
        table[x][y].coordinate = _val;
    }

    void setItem(int x, int y, tableItem item){
        lock.lock();
        table[x][y] = item;
        lock.unlock();
    }
}






@SuppressWarnings("ALL")
public class CYK {

    public static tableItem computeForSlot(int x,int y,triangleTable table){
        // collect all items going down and diagonal from this slot
        ArrayList<tableItem> forUnion = new ArrayList<tableItem>();
        int downStartX = x;
        int downStartY = 0;

        int diagonalStartX = x + 1;
        int diagonalStartY = y - 1;
        for(int steps = 0; steps < y;steps++){
            tableItem downItem = table.get(downStartX,downStartY);
            tableItem diagonalItem = table.get(diagonalStartX,diagonalStartY);
            tableItem multiplied = table.multiply(downItem,diagonalItem,x,y);
            forUnion.add(multiplied);
            downStartY+=1;
            diagonalStartX+=1;
            diagonalStartY-=1;
        }

        tableItem finalitem = table.union(forUnion,x,y);

        return finalitem;
    }

    public static boolean runCYK(String grammarFile,String toCheck) throws IOException {
        int SIZE = toCheck.length();
        triangleTable table = new triangleTable(SIZE,grammarFile);

        // compute the bottom row first.
        for(int i = 0; i < SIZE;i++){
            Collection<String> RHS = table.grammar.
                    getReverse(String.valueOf(toCheck.charAt(i)));
            if(RHS.size() == 0) {
                table.table[i][0].isNull = true;
            } else {
                table.table[i][0].vals = new ArrayList<String>(RHS);
            }
            table.table[i][0].evaluated.compareAndSet(false,true);
        }



        // now do all the rest.

        long startTime = System.currentTimeMillis();

       for(int  y = 1; y < SIZE;y++)
           for (int x = 0; x < SIZE; x++) {
               if (x + y >= SIZE) {
                   continue;
               } else {
                   //System.out.println(x);
                   table.table[x][y] = computeForSlot(x, y, table);
               }
           }


        long endTime   = System.currentTimeMillis();

        long totalTime = endTime - startTime;
        System.out.println("Time Taken " + totalTime);

        table.table[0][SIZE-1].print();


        return true;
    }


    public static void main(String[] args) throws IOException {

        String test = "baabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaabbaab";
        String testTwo = "baaba";

        System.out.println("RUNNING CYK SERIAL ");
        System.out.println("STRING TO TEST IS: " + test);

        for(int i = 0 ; i < 4;i++){
            System.out.println("Test Number: " + i);
            runCYK("grammar.txt",test);
        }






    }
}