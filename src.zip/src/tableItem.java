import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by irtazasafi on 16/10/2016.
 */
public class tableItem {
    volatile AtomicBoolean evaluated;
    volatile String coordinate;
    volatile ArrayList<String> vals;
    volatile int checkCount = 0;
    boolean isNull;
    tableItem(String _value,boolean _isNull){
        isNull = _isNull;
        coordinate = _value;
        evaluated = new AtomicBoolean(false);
        vals = new ArrayList<String>();
    }


    void print() {
        if (isNull) {
            System.out.print('#' + " ");
        } else {
            vals.forEach((String val) -> {
                System.out.print(val + " ");
            });
        }
    }

//    tableItem copy(){
//
//        tableItem ret = new tableItem(coordinate,isNull);
//        vals.forEach(val->{
//            ret.vals.add(val);
//        });
//
//
//
//    }
}
